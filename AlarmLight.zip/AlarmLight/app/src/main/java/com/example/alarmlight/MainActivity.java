package com.example.alarmlight;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private TextView threshtext;
    private Button increaseButton;
    private Button decreaseButton;
    private Button execButton;
    private int count = 50;

    private final String DEFAULTURL = "http://192.168.1.70/?";

    private String uri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        threshtext = (TextView) findViewById(R.id.threshold);
        increaseButton = findViewById(R.id.button_increase);
        decreaseButton = findViewById(R.id.button_decrease);
        execButton = findViewById(R.id.button_php);

        increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseCount();
                LEDTest task = new LEDTest();
                task.execute(count);
            }
        });

        decreaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decreaseCount();
                LEDTest task = new LEDTest();
                task.execute(count);
            }
        });

        execButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Alarm.class);
                intent.putExtra("threshold", count);
                startActivity(intent);
            }
        });

    }

    private void increaseCount() {
        count++;
        updateCountText();

    }
    private void decreaseCount() {
        if (count > 0) {
            count--;
            updateCountText();
        }
    }

    private void updateCountText() {
        threshtext.setText(String.valueOf(count));
    }

}