package com.example.alarmlight;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Alarm extends AppCompatActivity{
    int thresh;
    private TextView timeTextView;
    private TimePicker timePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alarm);

        timePicker = findViewById(R.id.timePicker);
        timeTextView = findViewById(R.id.tvSelectedTime);

        Button btnSetAlarm = findViewById(R.id.btnSetAlarm);
        thresh = getIntent().getIntExtra("threshold",0);
        btnSetAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAlarm();
            }
        });
    }
    private void setAlarm() {
        int hour, minute;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            hour = timePicker.getHour();
            minute = timePicker.getMinute();
        } else {
            hour = timePicker.getCurrentHour();
            minute = timePicker.getCurrentMinute();
        }

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);

        long triggerTimeMillis = calendar.getTimeInMillis();

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        // 選択した時間を表示する
        String selectedTime = String.format("%02d:%02d", hour, minute);
        timeTextView.setText("選択した時間: " + selectedTime);
        String th = String.format("%d", thresh);
        PHP task = new PHP();
        task.execute(th,selectedTime);


        Toast.makeText(this, "アラームが設定されました", Toast.LENGTH_SHORT).show();
    }
}
